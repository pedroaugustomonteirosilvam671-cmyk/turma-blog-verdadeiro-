using System;
using System.Collections.Generic;
using BLOGGGG.Models;

namespace BLOGGGG.Views;

public class PublicacaoView
{
    public (string Titulo, string Conteudo) SolicitarDadosPublicacao()
    {
        Console.Write("Título da publicação: ");
        string titulo = Console.ReadLine() ?? string.Empty;

        Console.Write("Conteúdo da publicação: ");
        string conteudo = Console.ReadLine() ?? string.Empty;

        return (titulo, conteudo);
    }

    public void ExibirPublicacao(Publicacao publicacao)
    {
        Console.WriteLine($"\n====================================");
        Console.WriteLine($"TÍTULO: {publicacao.Titulo}");
        Console.WriteLine($"AUTOR: {publicacao.Autor.Nome} | DATA: {publicacao.DataCriacao:dd/MM/yyyy HH:mm}");
        Console.WriteLine($"------------------------------------");
        Console.WriteLine(publicacao.Conteudo);
        Console.WriteLine($"====================================");
    }
}